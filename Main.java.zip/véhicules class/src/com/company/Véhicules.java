package com.company;

public class Véhicules {
    String vitre;
    int nbrRoue;
    int poids;
    String marque;

    public Véhicules () {};

    public Véhicules (String vitre, int nbrRoue, int poids, String marque) {
        this.vitre = vitre;
        this.nbrRoue = nbrRoue;
        this.poids = poids;
        this.marque = marque;

    }

    public String getVitre() {
        return vitre;
    }

    public void setVitre(String vitre) {
        this.vitre = vitre;
    }


    public int getNbrRoue() {
        return nbrRoue;
    }

    public void setNbrRoue(int nbrRoue) {
        this.nbrRoue = nbrRoue;
    }

    public int getPoids() {
        return poids;
    }

    public void setPoids(int poids) {
        this.poids = poids;
    }

    public String getMarque() {
        return marque;
    }

    public void setMarque(String marque) {
        this.marque = marque;
    }


};


