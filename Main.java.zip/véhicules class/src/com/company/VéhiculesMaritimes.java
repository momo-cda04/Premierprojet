package com.company;

public class VéhiculesMaritimes extends Véhicules {
    String gouvernail;

    public VéhiculesMaritimes () {super ();}

    public VéhiculesMaritimes (String vitre, int poids, int nbrRoue, String marque, String gouvernail) {
        super(vitre, poids, nbrRoue, marque);
        this.gouvernail = gouvernail;

    }

    public String getGouvernail() {
        return gouvernail;
    }

    public void setGouvernail(String gouvernail) {
        this.gouvernail = gouvernail;
    }
}


