package com.company;

public class VéhiculesAérien extends Véhicules {
    int nbrRoue3 = 2;
    int helice = 2;

    public VéhiculesAérien () {super();};

    public VéhiculesAérien (String vitre, int nbrRoue, int poids, String marque, int nbrRoue3, int helice) {
        super(vitre, poids, nbrRoue, marque);
        this.nbrRoue3 = nbrRoue3;
        this.helice = helice;
    }

    public int getNbrRoue3() {
        return nbrRoue3;
    }

    public void setNbrRoue3(int nbrRoue3) {
        this.nbrRoue3 = nbrRoue3;
    }

    public int getHelice() {
        return helice;
    }

    public void setHelice(int helice) {
        this.helice = helice;
    }
}

