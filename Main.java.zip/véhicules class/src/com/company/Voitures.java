package com.company;

public class Voitures extends VéhiculesTerrestres {
    String volant;
    int nbrRoue2 = 4;


    public Voitures () {super();};

    public Voitures (String vitre, int poids, int nbrRoue, int nbrRoue2, String marque, String volant) {
        super(vitre, poids, nbrRoue, marque);
        this.volant = volant;
    }

    public String getVolant() {
        return volant;
    }

    public void setVolant(String volant) {
        this.volant = volant;
    }

    @Override
    public int getNbrRoue2() {
        return nbrRoue2;
    }

    @Override
    public void setNbrRoue2(int nbrRoue2) {
        this.nbrRoue2 = nbrRoue2;
    }
}
