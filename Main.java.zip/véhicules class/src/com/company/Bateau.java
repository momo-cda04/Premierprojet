package com.company;

public class Bateau extends VéhiculesMaritimes {

}
