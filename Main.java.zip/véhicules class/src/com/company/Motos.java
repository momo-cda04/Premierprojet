package com.company;

public class Motos extends VéhiculesTerrestres {
    String guidon;

    public Motos () {super();};

    public String getGuidon() {
        return guidon;
    }

    public void setGuidon(String guidon) {
        this.guidon = guidon;
    }

    public Motos (String vitre, int poids, int nbrRoue, String marque, String guidon, int nbrRoue1) {
        super(vitre, poids, nbrRoue, marque);
        this.guidon = guidon;

    }


}
