package com.company;

public class Avion extends VéhiculesAérien {

}
