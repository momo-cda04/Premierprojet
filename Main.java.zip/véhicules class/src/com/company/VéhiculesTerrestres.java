package com.company;

public class VéhiculesTerrestres extends Véhicules {
    int nbrRoue1 = 2;
    int nbrRoue2 = 4;


    public VéhiculesTerrestres () {super();};


    public int getNbrRoue1() {
        return nbrRoue1;
    }

    public void setNbrRoue1(int nbrRoue1) {
        this.nbrRoue1 = nbrRoue1;
    }

    public int getNbrRoue2() {
        return nbrRoue2;
    }

    public void setNbrRoue2(int nbrRoue2) {
        this.nbrRoue2 = nbrRoue2;
    }

    public VéhiculesTerrestres (String vitre, int nbrRoue , int nbrRoue1, int nbrRoue2, int poids, String marque) {
        super(vitre, nbrRoue, poids, marque);
        this.nbrRoue1 = nbrRoue1;
        this.nbrRoue2 = nbrRoue2;

    }
}


