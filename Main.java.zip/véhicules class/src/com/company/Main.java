package com.company;

public class Main {

	public static void main(String[] args) {
	System.out.println("voici les différences entre les véhicules");

	Véhicules véhicules = new Véhicules();
	Véhicules véhicules1 = new Véhicules(véhicules.vitre, véhicules.nbrRoue, véhicules.poids, véhicules.marque);




	}
}
